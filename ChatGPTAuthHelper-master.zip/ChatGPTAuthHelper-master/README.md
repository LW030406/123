# ChatGPT Auth Helper

一个简单的 `Chrome` 插件，用来帮助你登录 `ChatGPT`。

### 使用步骤：

1. 前往 [Release](https://github.com/wozulong/ChatGPTAuthHelper/releases) 下载 `zip` / `tar.gz` 并解压缩。
2. 打开 `Chrome` ，地址栏输入： `chrome://extensions` 打开 `扩展程序` 设置页面。
3. 右上角打开 `开发者模式` 。
4. 点击左上角 `加载已解压的扩展程序` 按钮，选择刚下载解压的插件文件夹内的 `src` 目录，确定安装。
5. 你可以在 `扩展程序` 中看到 `ChatGPT Auth Helper` 说明安装成功。
6. 现在你的 `Chrome` 可以用来使用 `https://ai.fakeopen.com/auth` 服务了。
