const evt = new CustomEvent('ChatGPTAuthHelperEvent120', {});
window.dispatchEvent(evt);
